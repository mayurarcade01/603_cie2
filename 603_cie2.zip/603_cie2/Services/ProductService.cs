using System.Net.Http.Json; // Provides methods for reading JSON HTTP responses.
using _603_cie2.Models; // Imports the Product model.

// Defines the service namespace.
namespace _603_cie2.Services;

// Provides asynchronous product API operations.
public class ProductService
{
    private readonly HttpClient _httpClient; // Stores the HTTP client.

    // Receives HttpClient through dependency injection.
    public ProductService(HttpClient httpClient)
    {
        _httpClient = httpClient; // Saves the HTTP client.
    }

    // Retrieves products asynchronously from Fake Store API.
    // Retrieves product data asynchronously from the Fake Store API.
public async Task<List<Product>> GetProductsAsync()
{
    // Gets product data from the API and converts JSON into Product objects.
    var products = await _httpClient.GetFromJsonAsync<List<Product>>(
        "https://fakestoreapi.com/products");

    // Assigns a sample 10% discount to every product.
    if (products != null)
    {
        foreach (var product in products)
        {
            product.DiscountPercentage = 10; // Sets the product discount to 10%.
        }
    }

        // Returns the products or an empty list if no data was received.
        return products ?? new List<Product>();
    }
}