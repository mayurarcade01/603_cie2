using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using _603_cie2.Models;
using Microsoft.Extensions.Caching.Memory; // Provides in-memory caching.
using _603_cie2.Services; // Imports the product service.

namespace _603_cie2.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;
    private readonly IMemoryCache _cache; // Stores product data temporarily in memory.
private readonly ProductService _productService; // Retrieves products asynchronously from the API.

    public HomeController(
    ILogger<HomeController> logger,
    IMemoryCache cache,
    ProductService productService)
{
    _logger = logger; // Stores the logger.
    _cache = cache; // Stores the memory cache service.
    _productService = productService; // Stores the product API service.
}

    public async Task<IActionResult> Index()
{
    // Retrieves products from cache or calls the API when the cache is empty.
    var products = await _cache.GetOrCreateAsync("products", async entry =>
    {
        entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(10); // Keeps products cached for 10 minutes.
        return await _productService.GetProductsAsync(); // Retrieves products asynchronously.
    });

    // Reads the customer name from the cookie.
    ViewBag.CustomerName = Request.Cookies["CustomerName"];

    // Reads the selected category from the session.
    ViewBag.Category = HttpContext.Session.GetString("Category");

    // Sends products to the product list view.
    return View(products ?? new List<Product>());
}


[ResponseCache(Duration = 60)] // Caches the product details response for 60 seconds.
public async Task<IActionResult> Details(int id)
{
    // Retrieves the cached product list.
    var products = await _cache.GetOrCreateAsync("products", async entry =>
    {
        entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(10); // Sets a 10-minute cache.
        return await _productService.GetProductsAsync(); // Retrieves products from the API.
    });

    // Finds the product using the ProductId passed through the query string.
    var product = products?.FirstOrDefault(p => p.ProductId == id);

    // Displays an error page if the product does not exist.
    if (product == null)
        return NotFound();

    // Displays the selected product.
    return View(product);
}


// Saves the customer name in a browser cookie.
[HttpPost]
public IActionResult SaveCustomer(string customerName)
{
    Response.Cookies.Append("CustomerName", customerName); // Stores the customer name in a cookie.
    return RedirectToAction("Index"); // Returns to the product list.
}

// Saves the selected category in the session.
[HttpPost]
public IActionResult SaveCategory(string category)
{
    HttpContext.Session.SetString("Category", category); // Stores the category in session.
    return RedirectToAction("Index"); // Returns to the product list.
}

// Receives the ProductId from the hidden form field.
[HttpPost]
public IActionResult Order(int productId)
{
    TempData["Message"] = $"Product {productId} selected successfully."; // Stores the selection message.
    return RedirectToAction("Index"); // Returns to the product list.
}



    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
