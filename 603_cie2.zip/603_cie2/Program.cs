var builder = WebApplication.CreateBuilder(args);

builder.Services.AddMemoryCache(); // Enables in-memory caching for product data.
builder.Services.AddHttpClient<ProductService>(); // Registers HttpClient and ProductService for API requests.
builder.Services.AddSession(); // Enables session state management.

// Add services to the container.
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.UseSession(); // Enables session state for customer selections.

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
