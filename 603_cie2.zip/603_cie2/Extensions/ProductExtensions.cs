using _603_cie2.Models; // Imports the Product model.

namespace _603_cie2.Extensions; // Defines the extension method namespace.

// Provides extension methods for Product.
public static class ProductExtensions
{
    // Calculates the discounted selling price of a product.
    public static decimal GetDiscountedPrice(this Product product)
    {
        return product.Price - (product.Price * product.DiscountPercentage / 100); // Applies the discount.
    }
}