global using _603_cie2.Models; // Makes Product available throughout the project.
global using _603_cie2.Extensions; // Makes Product extension methods available throughout the project.
global using _603_cie2.Services; // Makes ProductService available throughout the project.