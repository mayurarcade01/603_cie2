using System.Text.Json.Serialization; // Provides JSON property mapping.

namespace _603_cie2.Models; // Defines the namespace for the Product model.

// Represents a product in the shopping system.
public class Product
{
    [JsonPropertyName("id")] // Maps the API's "id" field to ProductId.
    public int ProductId { get; set; } // Stores the unique product ID.

    [JsonPropertyName("title")] // Maps the API's "title" field to ProductName.
    public string ProductName { get; set; } = ""; // Stores the product name.

    public string Category { get; set; } = ""; // Stores the product category.
    public decimal Price { get; set; } // Stores the original product price.
    public decimal DiscountPercentage { get; set; } // Stores the discount percentage.
}